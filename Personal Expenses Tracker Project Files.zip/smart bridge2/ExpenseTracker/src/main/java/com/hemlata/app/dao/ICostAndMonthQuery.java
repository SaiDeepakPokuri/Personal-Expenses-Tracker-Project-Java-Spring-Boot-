package com.hemlata.app.dao;

public interface ICostAndMonthQuery {
	public Integer getCost();
	public String getMonth();
}
