package com.hemlata.app.dao;

public interface ICostAndDateQuery {
	Integer getCost();
	String getDate();
}
